# Instructions

1. Install python3

2. Install python requirements :  

```bash
python3 -m pip install -r app/requirements.txt
```

3. Run :  

```bash
cd app
flask run
```
